#!/bin/bash
./server config.ini
