Budowanie:
scons w katalogu sandbox

Biblioteka składa się z nagłówków, należy dołączać pliki znajdujące się w katalogu mt4cpp.

Zależności:
boost
zeromq (http://zeromq.org/intro:get-the-software)
python-zmq

W razie problemów z plikiem zmq.hpp można go pobrać stąd:
https://github.com/zeromq/cppzmq/blob/master/zmq.hpp

Testy:
Program testAll
Wymagają uruchomionego programu przykładowego server.

